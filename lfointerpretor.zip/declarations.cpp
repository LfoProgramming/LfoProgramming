#include <string>

int getNumber(char *c)
{
    int result=0;
    while(*c!=' '&&*c!='\0'&&*c!='\n')
        {
            result*=10;
            result+= *c-'0';
            c++;
        }
    return result;
}

