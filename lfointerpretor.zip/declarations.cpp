#include <iostream>
#include <string>
#include <fstream>
#include <map>
#include <windows.h>
#include <string.h>
#include "Type.h"
#include "Function.h"
#include "Int_type.h"
#include "declarations.h"

using namespace::std;

extern std::map<std::string, Function> functions;
extern std::map<std::string, Type*> variables;

int getNumber(char *c)
{int m=1;
    int result=0;
    if(*c=='-')
        {
        m=-1;
        c++;
        }
    while(*c!=' '&&*c!='\0'&&*c!='\n')
        {
            result*=10;
            result+= *c-'0';
            c++;
        }
    return result*m;
}

 void read()
    {
        int a;
        cin>>a;
        delete functions["read"].ret;
        functions["read"].ret = new Int_type(a);
      //  *(int*)(functions["read"].ret->getcontent())=a;
    }

       void show()
    {

       // cout<<"Value: "<<*(int*)(functions["print"].parameters[0]->getcontent())<<endl;
         for(int i=0;i<functions["print"].parameters.size();i++)
        cout<<*(int*)(variables[functions["print"].parameters[i]]->getcontent())<<" ";

        cout<<endl;
    }

    void cls(){system("cls");}

    void pause(){system("pause");}

    void add()
    {
        int sum=0;

        for(int i=0;i<functions["sum"].parameters.size();i++)
            {
            sum+=*(int*)(variables[functions["sum"].parameters[i]]->getcontent());
            }

        delete functions["sum"].ret;
        functions["sum"].ret = new Int_type(sum);
    }

      void minu()
    {
        int sum=0;

        for(int i=0;i<functions["minus"].parameters.size();i++)
            {
            sum-=*(int*)(variables[functions["minus"].parameters[i]]->getcontent());
            }

        delete functions["minus"].ret;
        functions["minus"].ret = new Int_type(sum);
    }

     void multiply()
    {
        int sum=1;

        for(int i=0;i<functions["multiply"].parameters.size();i++)
            {
            sum*=*(int*)(variables[functions["multiply"].parameters[i]]->getcontent());
            }

        delete functions["multiply"].ret;
        functions["multiply"].ret = new Int_type(sum);
    }

      void divide()
    {
        int sum=0;

        for(int i=0;i<functions["divide"].parameters.size();i++)
            {
            sum/=*(int*)(variables[functions["divide"].parameters[i]]->getcontent());
            }

        delete functions["sum"].ret;
        functions["sum"].ret = new Int_type(sum);
    }

namespace lib
{
    void loadIO()
    {
        functions["read"]=read;
        functions["print"]=show;
        functions["cls"]=cls;
        functions["pause"]=pause;
    }

    void loadMath()
    {
        functions["sum"]=add;
        functions["minus"]=minu;
        functions["multiply"]=multiply;
        functions["divide"]=divide;
    }


}
