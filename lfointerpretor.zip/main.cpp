#include <iostream>
#include <string>
#include <fstream>
#include <map>
#include <windows.h>
#include <string.h>
#include "Type.h"
#include "Function.h"
#include "Int_type.h"
#include "declarations.h"

using namespace std;


std::map<std::string, Function> functions;
std::map<std::string, Type*> variables;


int comparestr(char *a, char *b)
{
    while(1)
        {
            if((*a==' '||*a=='\0')&&(*b==' '||*b=='\0')){return 0;}
            if(*a!=*b){return 1;}
            a++;b++;
        }

}

char extract(char *c)
{
    int count=0;
    char *i=c;
    while(*i!=' '&&*i!='\n'&&*i!='\n')i++;

}



void executeF(char* c)
{
    char fname[100]={0};
    char *i=c;
    int ii=0;
    while(*i!=' '&&*i!='\0'&&*i!='\n')
        {
            fname[ii]=*i;
            ii++;
            i++;
        }

    functions[fname].parameters.clear();
    char *p=c;
    while(*p!='\n'&&*p!=' '){p++;}

    while(1)
    {

        if(*p==' ')
        {p++;

            if(*p=='$')
                {p++;
                     char pname[100]={0};

                char *i=p;
                int ii=0;
                while(*i!=' '&&*i!='\0'&&*i!='\n')
                    {
                        pname[ii]=*i;
                        ii++;
                        i++;
                    }

                    p+=ii;
                    functions[fname].parameters.push_back(pname);
                   // functions[fname].parameters[varcount]=variables[p];

                }else
                {
                    break;
                }

        }else{break;};
    }

    functions[fname].run();
}

char* loadvariable(char* c)
{
char fname[100]={0};

    if(comparestr(c, "int")==0)
        {
            c+=4;

        char *i=c;
        int ii=0;
        while(*i!=' '&&*i!='\0'&&*i!='\n')
            {
                fname[ii]=*i;
                ii++;
                i++;
            }

            variables[fname]=new Int_type();
            //*((int*)(variables[c]->getcontent()))=4;
        }
else if(comparestr(c, "float")==0)
        {

        }
    //variables[c];

    return c+strlen(fname);
}

    void show()
    {

       // cout<<"Value: "<<*(int*)(functions["print"].parameters[0]->getcontent())<<endl;

        cout<<"Value: "<<*(int*)(variables[functions["print"].parameters[0]]->getcontent())<<endl;
    }

    void add()
    {
        int sum=0;

        for(int i=0;i<functions["add"].parameters.size();i++)
            {
            sum+=*(int*)(variables[functions["add"].parameters[i]]->getcontent());
            }

        cout<<"sum: "<<sum<<endl;
    }

    //*(int*)(variables[functions["add"].parameters[0]]->getcontent());   //parametrul 0

    void read()
    {
        int a;
        cin>>a;
        delete functions["read"].ret;
        functions["read"].ret = new Int_type(a);
      //  *(int*)(functions["read"].ret->getcontent())=a;
    }


int main()
{

    functions["click"]=Function([](){Beep(100,100);});
    functions["show"]=Function([](){cout<<"show\n";});
    functions["show2"]=Function([](){cout<<"show2\n";});
    functions["sleep"]=Function([](){Sleep(1000);});


    functions["add"]=add;
    functions["read"]=read;


    functions["print"]=show;
    //functions["print"].parameters.push_back();
    //functions["assign"]=asign;



    ifstream file("lol.lfop");
    if(!file.is_open())
        {
        return 1;
        }

    while(!file.eof())
        {
         char line[250]={0};

            file.getline(line, 250);

            int pos=0;
            for(pos=0; line[pos]==' '||line[pos]=='\t'; pos++){};

            for(;line[pos]!=0;pos++)
                {
                    if(line[pos]=='@')
                        {
                            executeF(&line[pos+1]);
                            break;
                        }
                else if(line[pos]=='$')
                        {
                            char fname[100]={0};
                                    char *i=&line[pos+1];
                                    int ii=0;
                                    while(*i!=' '&&*i!='\0'&&*i!='\n')
                                        {
                                            fname[ii]=*i;
                                            ii++;
                                            i++;
                                        }
                                        ii++;
                                        i++;
                                      while(*i!=' '&&*i!='\0'&&*i!='\n')
                                        {
                                            fname[ii]=*i;
                                            ii++;
                                            i++;
                                        }

                            char *c=loadvariable(fname);

                            if(line[ii+2]=='=')
                                {
                                    *((int*)variables[&fname[strlen(fname)+1]]->getcontent())=getNumber(&line[ii+4]);
                                }


                            break;
                        }
                else if(line[pos]=='~')
                    {
                        break;
                    }
                else            ///variabile
                    {
                        char vname[100]={0};
                                    char *i=line;
                                    int ii=0;
                                    while(*i!=' '&&*i!='\0'&&*i!='\n')
                                        {
                                            vname[ii]=*i;
                                            ii++;
                                            i++;
                                        }

                                        ii+=3;
                                        i+=3;

                                        if(line[ii]=='@')
                                    {
                                            executeF(&line[ii+1]);
                                        char fname[100]={0};
                                        i=&line[ii+1];
                                         ii=0;
                                        while(*i!=' '&&*i!='\0'&&*i!='\n')
                                            {
                                                fname[ii]=*i;
                                                ii++;
                                                i++;
                                            }

                                            *((int*)variables[vname]->getcontent())=*(int*)(functions[fname].ret->getcontent());
                                            break;
                                    }else
                                    {
                                       *((int*)variables[vname]->getcontent())=getNumber(&line[ii]);
                                    }

                    }

                }


        }
    file.close();

    cout<<"\nProcess ended\n";
    cin.get();
    return 0;
}
