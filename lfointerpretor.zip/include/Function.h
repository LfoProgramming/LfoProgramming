#ifndef FUNCTION_H
#define FUNCTION_H
#include <vector>
#include "Type.h"
#include <memory>

class Function
{
    public:
        Function();
        Function(void(*fpointer_)()){fpointer=fpointer_;};
        std::vector<std::string> parameters;
        Type* ret=0;

        void(*fpointer)() = nullptr;
        int beginline;
        int endline;

        void run();
};

#endif // FUNCTION_H
