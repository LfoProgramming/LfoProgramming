#ifndef FUNCTION_H
#define FUNCTION_H
#include <vector>
#include "Type.h"

class Function
{
    public:
        Function();
        Function(void(*fpointer_)()){fpointer=fpointer_;};
        std::vector<std::string> parameters;
        Type *ret;

        void(*fpointer)() = nullptr;
        int beginline;
        int endline;

        void run();
};

#endif // FUNCTION_H
