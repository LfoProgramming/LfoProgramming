#ifndef DECLARATIONS_H_INCLUDED
#define DECLARATIONS_H_INCLUDED
int getNumber(char *c);


namespace lib
{
    void loadIO();
    void loadMath();
}



#endif // DECLARATIONS_H_INCLUDED
