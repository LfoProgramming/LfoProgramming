#ifndef DECLARATIONS_H_INCLUDED
#define DECLARATIONS_H_INCLUDED
int getNumber(char *c);


#endif // DECLARATIONS_H_INCLUDED
