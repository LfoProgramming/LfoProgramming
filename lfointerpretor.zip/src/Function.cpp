#include "Function.h"

Function::Function()
{
    //ctor
}

void Function::run()
{
    if(fpointer)
        {
        fpointer();
        }else
        {

        }
}
