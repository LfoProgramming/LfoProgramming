#include "Function.h"
#include "Int_type.h"

Function::Function()
{

    //ctot
}

void Function::run()
{
    if(fpointer)
        {
        fpointer();
        }else
        {

        }

}

