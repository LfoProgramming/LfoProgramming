#include "Type.h"

Type::Type()
{
    //ctor
}
